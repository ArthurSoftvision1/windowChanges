# Window changes

# What it does

This add-on lets the user to make some changes while he is using the browser.

# What it shows

The user can resize his current window, create incognito pages and use the browser as he wants.

* How to use it: You can download the extension from this address(https://developer.mozilla.org/en-US/Add-ons/WebExtensions/windowChanges) and after that you just drag and drop into your Mozilla Firefox browser the windowChanges.xpi file.

